"""
-------------------------------------------------------
Lab 4, Task 1
-------------------------------------------------------
Author:  Jashandeep Singh
ID:      169018282
Email:   sing8282@mylaurier.ca
__updated__ = "2023-02-10"
-------------------------------------------------------
"""
# Imports

from Movie import Movie

key = Movie('Juno', 2007, None, None, None)
print(key)
