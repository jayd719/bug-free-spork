"""
-------------------------------------------------------
Lab 10, Task 2
-------------------------------------------------------
Author:  Jashandeep Singh
ID:      169018282
Email:   sing8282@mylaurier.ca
__updated__ = "2023-03-30"
-------------------------------------------------------
"""
# Imports
from test_Sorts_array import test_sort
from Sorts_array import Sorts

test_sort('Bubble Sort', Sorts.bubble_sort)
