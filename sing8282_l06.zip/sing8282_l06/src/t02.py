"""
-------------------------------------------------------
Lab 6, Task
-------------------------------------------------------
Author:  Jashandeep Singh
ID:      169018282
Email:   sing8282@mylaurier.ca
__updated__ = "2023-03-03"
-------------------------------------------------------
"""
# Imports
from List_linked import List

source = List()
target = List()

source.append(99)


print(source == target)

print(source[-1])
