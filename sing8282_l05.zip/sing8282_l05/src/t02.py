"""
-------------------------------------------------------
Lab 5, Task 2
-------------------------------------------------------
Author:  Jashandeep Singh
ID:      169018282
Email:   sing8282@mylaurier.ca
__updated__ = "2023-02-18"
-------------------------------------------------------
"""
# Imports
from functions import gcd


x = 9
y = 6

ans = gcd(x, y)

print(ans)
