"""
-------------------------------------------------------
Lab 5, Task 1
-------------------------------------------------------
Author:  Jashandeep Singh
ID:      169018282
Email:   sing8282@mylaurier.ca
__updated__ = "2023-02-18"
-------------------------------------------------------
"""
# Imports
from functions import recurse
x = 5
y = 3

ans = recurse(x, y)

print(ans)
