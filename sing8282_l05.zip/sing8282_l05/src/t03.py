"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Jashandeep Singh
ID:      169018282
Email:   sing8282@mylaurier.ca
__updated__ = "2023-02-18"
-------------------------------------------------------
"""
# Imports
from functions import vowel_count


count = vowel_count('Thiese')
print(count)


print(vowel_count('atom'))
print(vowel_count(''))
print(vowel_count('your'))
