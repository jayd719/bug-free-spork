"""
-------------------------------------------------------
Lab 4, Task 4
-------------------------------------------------------
Author:  Jashandeep Singh
ID:      169018282
Email:   sing8282@mylaurier.ca
__updated__ = "2023-02-18"
-------------------------------------------------------
"""
# Imports
from functions import to_power

base = 2
power = -2
ans = to_power(base, power)

print(ans)
