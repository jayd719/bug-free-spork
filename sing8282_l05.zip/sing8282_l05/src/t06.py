"""
-------------------------------------------------------
Lab 5, Task 6
-------------------------------------------------------
Author:  Jashandeep Singh
ID:      169018282
Email:   sing8282@mylaurier.ca
__updated__ = "2023-02-18"
-------------------------------------------------------
"""
# Imports
from functions import bag_to_set

bag = [4, 5, 3, 4, 5, 2, 2, 4, 9]
new_set = bag_to_set(bag)
print(new_set)
