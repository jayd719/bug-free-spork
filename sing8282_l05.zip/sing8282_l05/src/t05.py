"""
-------------------------------------------------------
Lab 5, Task 5
-------------------------------------------------------
Author:  Jashandeep Singh
ID:      169018282
Email:   sing8282@mylaurier.ca
__updated__ = "2023-02-18"
-------------------------------------------------------
"""
# Imports

from functions import is_palindrome

palindrome = is_palindrome('A man, a plan, a canal, Panama!')

print(palindrome)
